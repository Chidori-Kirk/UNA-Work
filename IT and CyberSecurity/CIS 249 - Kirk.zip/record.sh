#!/bin/sh
# CS 249, Fall 2016
# Record the user's shell session in a log for submission
# Use winscp to sftp the session log to the windows host for submission
echo 'Press CTRL-D to end the logging session.'
echo 'Retrieve the log file with WinSCP when the tutorial is complete.'
echo 'Submit the log file to canvas.'
/usr/bin/script -f /tmp/$(date +"%d-%b-%y_%H-%M-%S")_shell.log
