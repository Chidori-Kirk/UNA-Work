<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
<?php include 'prices.php';?>
<div style="border: solid 1px black; margin-left: 40%; margin-right: 40%;">
  <center>
    <h1>Order Summary</h1>
    <p>This is a summary of the orders you have decided to purchase. Is this summary correct?</p><br>
    <?php
      $_SESSION["groundedCoffee"] = $_REQUEST["groundedCoffee"];
      $_SESSION["coffeeBeans"] = $_REQUEST["coffeeBeans"];
      $_SESSION["grinder"] = $_REQUEST["grinder"];
      $_SESSION["mug"] = $_REQUEST["mug"];
      $_SESSION["coffeeMachine"] = $_REQUEST["coffeeMachine"];

      $totalGroundedCoffee = $_SESSION['groundedCoffee']*$groundedCoffee;
      $totalCoffeeBeans = $_SESSION['coffeeBeans']*$coffeeBeans;
      $totalGrinder = $_SESSION['grinder']*$grinder;
      $totalMug = $_SESSION['mug']*$mug;
      $totalCoffeeMachine = $_SESSION['coffeeMachine']*$coffeeMachine;

      $_SESSION['subtotal'] = $totalGroundedCoffee + $totalCoffeeBeans + $totalGrinder + $totalMug + $totalCoffeeMachine;

      echo $_POST['groundedCoffee']." <b>Grounded Coffee</b>"."<br>"." <kbd>Sum is: $" . $_POST['groundedCoffee']*$groundedCoffee. "</kbd><br><br>";
      echo $_POST["coffeeBeans"]." <b>Coffee Beans</b>"."<br>"." <kbd>Sum is: $" .$_POST['coffeeBeans']*$coffeeBeans. "</kbd><br><br>";
      echo $_POST['grinder']. " <b>Grinders</b>". "<br>"." <kbd>Sum is: $" .$_POST['grinder']*$grinder."</kbd><br><br>";
      echo $_POST['mug']. " <b>Mugs</b>". "<br>"." <kbd>Sum is: $" .$_POST['mug']*$mug."</kbd><br><br>";
      echo $_POST['coffeeMachine']." <b>Coffee Machines</b>". "<br>"." <kbd>Sum is: $" .$_POST['coffeeMachine']*$coffeeMachine. "</kbd><br><br>";

      echo "<b>Your subtotal is:</b> <kbd>$". $_SESSION['subtotal']."</kbd><br><br>";
    ?>

    <form action="index.php">
      <input style="margin-right: 85px;" class="btn btn-secondary" type="submit" value="Cancel">
    </form>
    <form action="subtotalTaxTotal.php">
      <input style="margin-left: 85px; margin-top: -48px;" class="btn btn-primary" type="submit" value="Continue">
    </form>
  </center>
</div>
