<?php
//Starts the session
session_start();
?>

<?php
  $groundedCoffee = 5;
  $coffeeBeans = 2;
  $grinder = 10;
  $mug = 8;
  $coffeeMachine = 50;
?>
