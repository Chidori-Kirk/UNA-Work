<?php
  session_start();
 ?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
<div style="border: solid 1px black; margin-left: 40%; margin-right: 40%;">
  <div class="pull-right"><kbd>
    <?php
    echo "Welcome, ".$_SESSION['username'];

    ?>
</kbd></div>
  <center>
  <h1>Order Completed</h1>
  <p>Thank you for your purchase!</p>
  <form action="cart1.php">
    <input type="submit" class="btn btn-success" value="Return Home">
  </form>
</div>
