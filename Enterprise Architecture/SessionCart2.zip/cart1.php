<?php session_start(); ?>
<?php
  $_SESSION['username'] = $_POST['username'];
 ?>
<?php include 'prices.php';?>
<html>
    <head>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
      <meta charset="UTF-8">
      <title>Premiun Coffee</title>
    </head>
    <body><b>
	<?php
	?></b>
      <div style="border: solid 1px black; margin-left: 40%; margin-right: 40%;">
        <div class="pull-right"><kbd>
        <?php

        function test_input($data) {
        	$data = trim($data);
        	$data =  stripslashes($data);
        	$data =  htmlspecialchars($data);
        	return $data;
        }

        	//init vars
        	$user = test_input($_POST['username']);
        	$pass = test_input($_POST['password']);

        	//validate the user and pass
        	if($pass === "secret") {
        		echo "Welcome, " . $user;
        	} else {
        		echo "Invalid username and/or password";
        	}
        ?>
      </kbd></div>
      <center>
        <h1>Premium Coffee</h1>
        <p>Check out our products!</p>
        <form action="summary.php" method="post">
          <b>Grounded Coffee</b><br><kbd><?php echo " $". $groundedCoffee . " a piece";?></kbd><br><input class="form-control-static" type="number" name="groundedCoffee" value = "<?= $_SESSION["groundedCoffee"] ?>"><br>
          <b>Coffee Beans</b><br><kbd><?php echo " $". $coffeeBeans . " a piece";?></kbd><br><input class="form-control-static" type="number" name="coffeeBeans"value = "<?= $_SESSION["coffeeBeans"] ?>"><br>
          <b>Grinders</b><br><kbd><?php echo " $". $grinder . " a piece";?></kbd><br><input class="form-control-static" type="number" name="grinder"value = "<?= $_SESSION["grinder"] ?>"><br>
          <b>Mugs</b><br><kbd><?php echo " $". $mug . " a piece";?></kbd><br><input class="form-control-static" type="number" name="mug"value = "<?= $_SESSION["mug"] ?>"><br>
          <b>Coffee Machines</b><br><kbd><?php echo " $". $coffeeMachine . " a piece";?></kbd><br><input class="form-control-static" type="number" name="coffeeMachine"value = "<?= $_SESSION["coffeeMachine"] ?>"><br>
          <br><button class="btn btn-primary" type="submit" value="next">Submit</button>
        </form>
      <center>
      </div>
    </body>
</html>
