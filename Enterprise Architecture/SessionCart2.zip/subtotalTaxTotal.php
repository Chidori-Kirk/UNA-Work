<?php
  session_start();
 ?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
<div style="border: solid 1px black; margin-left: 40%; margin-right: 40%;">
  <div class="pull-right"><kbd>
    <?php
    $user = $_SESSION['username'];


    function test_input($data) {
      $data = trim($data);
      $data =  stripslashes($data);
      $data =  htmlspecialchars($data);
      return $data;
    }

    echo "Welcome, ".$_SESSION['username'];

    ?>
</kbd></div>
  <center>
    <h1>Confirm Order</h1><br>
    <p>How will you be paying?</p>
    <div class="form-control">
    <input type="checkbox">American Express
    <input type="checkbox">VISA
    <input type="checkbox">MasterCard
  </div>
    <p>Please confirm your order</p>
<?php
$subtotal = $_SESSION['subtotal'];
$taxes = $subtotal * .085;
$total = $subtotal + $taxes;

echo "<b>Your Subtotal:</b> <kbd>$".$subtotal."</kbd><br>";
echo "<b>Total Taxes:</b> <kbd>$" . round($taxes,2)."</kbd><br>";
echo "<b>Your Total:</b> <kbd>$". round($total,2)."</kbd><br>";
?>
<br><form action="cart1.php">
  <input style="margin-right: 85px;" class="btn btn-secondary" type="submit" value = "Cancel">
</form>
<form action="finish.php">
  <input style="margin-left: 85px; margin-top: -48px;" class="btn btn-primary"type="submit" value = "Confirm">
</form>
</center>
</div>
