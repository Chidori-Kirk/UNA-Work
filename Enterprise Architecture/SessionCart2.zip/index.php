<?php session_start(); ?>
<!DOCTYPE html>
<html>
<body>
<form action="cart1.php" method="POST">
Username:<br>
<input type="text" name="username"><br>
Password:<br>
<input type="password" name="password">
<hr>
<em>
Remember Me
</em>
<input type="checkbox" name="remember" value="on">
<input type="submit" value="Submit">
</body
</html>
