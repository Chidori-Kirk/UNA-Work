<?php session_start(); ?>
<?php

function test_input($data) {
	$data = trim($data);
	$data =  stripslashes($data);
	$data =  htmlspecialchars($data);
	return $data;
}
	var_dump($_REQUEST);
	
	//init vars
	$user = test_input($_POST['username']);
	$pass = test_input($_POST['password']);
	
	//validate the user and pass
	
	if($pass === "secret") {
		echo "Welcome, " . $user;
		//setcookie("username", $user, time() + 3600);
		$_SESSION['mug'] = 3;
	} else {
		echo "Invalid username and/or password";
	}
?>