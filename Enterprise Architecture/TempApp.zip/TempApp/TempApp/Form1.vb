﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim inputTemp As Double
        Dim client As ServiceReference1.TempConvertSoapClient
        Dim answer As String
        client = New ServiceReference1.TempConvertSoapClient("TempConvertSoap12")

        'input
        inputTemp = txtInput.Text

        'call webservice
        answer = client.CelsiusToFahrenheit(inputTemp)

        'output
        lblOutput.Text = answer
    End Sub
End Class
