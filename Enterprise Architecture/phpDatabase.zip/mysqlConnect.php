<?php

$servername = "localhost";
$user = "root";
$password = "";
$dbname = "cis476";

$conn = new mysqli($servername, $user, $password, $dbname);
 // Check connection
 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}

?>
