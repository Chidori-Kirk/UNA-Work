<?php
session_start();
include 'mysqlConnect.php';
echo "<h2>You're logged in!</h2>";
  if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] == false) {
    header("Location: index.php");
  }

  echo "Username: ".strtolower($_SESSION['username'])." <br><a href=\"logout.php\">Logout</a><br>" . "<br>Data: <br>";

  $sql = "SELECT * FROM users";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
      echo  "<br>".$row["id"].": Username: ". $row["username"].", Age: ".  $row["age"].", Class: ".  $row["class"]. "<br>";
  }
} else {
  echo "0 results";
}
$conn->close();
 ?>
