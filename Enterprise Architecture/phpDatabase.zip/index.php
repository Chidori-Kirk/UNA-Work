<!DOCTYPE html>
<?php
session_start();

echo "The current day of the year number is " . date('z')."<br><br>";
$username = htmlspecialchars($_POST['username']);
$password = strrev($username).date('z');
$_SESSION['username'] = $username;

if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
  header("Location: validation.php");
}

if(isset($_POST['username']) && isset($_POST['password'])) {
  if ($_POST['username'] == $username && $_POST['password'] == $password) {
    $_SESSION['loggedin'] = true;
    header("Location: validation.php");
  }
}
?>
<html>
<body>
<form action="index.php" method="POST">
Username:<br>
<input type="text" name="username"><br>
Password:<br>
<input type="password" name="password"><br>
<input type="submit" value="Login">
</form>
</body>
</html>
