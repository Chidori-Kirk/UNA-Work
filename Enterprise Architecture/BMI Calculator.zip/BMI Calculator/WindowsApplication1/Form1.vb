﻿Public Class Form1

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        ' K&R -- C "Hello, World"
        'MessageBox.Show("hello, world")
        'input
        Dim ht As Integer
        Dim wt As Integer

        ht = nudHeight.Value
        wt = nudWeight.Value
        'processing
        Dim bmi As Double

        bmi = (wt / (ht * ht)) * 703
        'output

        lbOutput.Items.add("hello")
        lbOutput.Items.Add(ht)
        lbOutput.Items.Add(wt)
        lbOutput.Items.Add(bmi)
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Output.SelectedIndexChanged

    End Sub
End Class
