<?php

// TODO: insert data gathered from insert.php form into the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "officemin";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
 // Check connection
 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}

$brand = $_POST['brand'];
$product = $_POST['product'];
$price = $_POST['price'];

$sql = "INSERT INTO items (brand, product, price)
 VALUES ('$brand', '$product', '$price')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
header("location:index.php");
?>
