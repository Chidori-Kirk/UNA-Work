<?php
  session_start();
  if (isset($_SESSION['user'])) {
      $username = $_SESSION['user'];
  } else {
      header("location:login.php");
  }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        Enter the brand name of the product to delete.
        <form action="do_delete.php" method="post"
              onSubmit="if(confirm('Are you sure?')) return true; return false;">
            Brand: <input type="text" name="brand" />
            <input type="submit" />
        </form>
        TODO: create php page that performs the delete and then provides a link to the main menu.
    </body>
</html>
