<?php session_start();
 
if (isset($_POST['uname']) && isset($_POST['pwd'])) {
    $user = htmlspecialchars($_POST['uname']);
    $pwd = htmlspecialchars($_POST['pwd']);
    $len = strlen($user);
    if ($pwd === "letmein" && $len > 0) {
        $_SESSION['user'] = $user;
        header("location:index.php");
    }
}
?>
<!DOCTYPE html>
<html>
    <body>
        Invalid username and/or password.
        
        <a href="index.php">Main Menu</a>
    </body>
</html>
