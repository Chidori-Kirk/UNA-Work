<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        TODO: Display all data (except the id) from the database.
        <p />
        <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "officemin";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT brand, price, product FROM items";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo  $row["brand"]." ".  $row["product"]." ".  $row["price"]. "<br>";
    }
} else {
    echo "0 results";
}
$conn->close();
?>
    </body>
</html>
