<?php session_start() ?>
<?php
    if (isset($_SESSION['user'])) {
        $username = $_SESSION['user'];
    } else {
        header("location:login.php");
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        Welcome, <?= $user ?>
        <p />
        <form action="do_insert.php" method="post">
            Brand: <input type="text" name="brand"><br/>
            Product: <input type="text" name="product"><br/>
            Price: <input type="calendar" name="price"><br />
            <br/>
            <input type="submit"/>
        </form>
    </body>
</html>
