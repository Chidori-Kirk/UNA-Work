<!DOCTYPE html>
<html xmlns:mso="urn:schemas-microsoft-com:office:office" xmlns:msdt="uuid:C2F41010-65B3-11d1-A29F-00AA00C14882">
<head>
<title>PHP Test</title>
<style type= "text/css">
body{
	background-color:purple;

	}


div{
	color:black;
	border-style:solid;
	font-weight:bold;
}
</style>

<!--[if gte mso 9]><xml>
<mso:CustomDocumentProperties>
<mso:IsMyDocuments msdt:dt="string">1</mso:IsMyDocuments>
</mso:CustomDocumentProperties>
</xml><![endif]-->
</head>
<body >
<h1><center>This page demonstrates MySQL connectivity</center></h1>
<p></p>
<h2><center><u>Team 2</u></center></h2>
<h2><center>Orders Query</center></h2>
<div><center><?php 

	$connection = new mysqli('localhost', 'root', '', 'bil');
	if ($connection->connect_error) die ($connection->connect_error);
	
	$orders_query = "select * from orders";
	$result = $connection->query($orders_query);
	
	if (!$result) die ($connection->error);
	
	$row = $result->num_rows;
	
	for ($j = 0; $j < $rows; ++$j)
	{
		$result->data_seek($j);
		$row = $result->fetch_array(MYSQL_BOTH);
		echo $row['orderID'].' ';
		echo $row['customerID'].' ';
		echo $row['productID'].' ';
		echo $row['employeeID'].' ';
		echo $row['shipperID'].' ';
		echo $row['orderDate'].' ';
		echo $row['arrivalDate'].' ';
		echo $row['shipTo'].' ';
		echo $row['shipAddress'].' ';
		echo $row['shipCity'].' ';
		echo $row['shipState'].' ';
		echo $row['shipZipCode'].'<br>';
	}
	$result->close();
?></center></div>

</body>
</html>