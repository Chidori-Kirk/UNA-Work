-- MySQL dump 10.13  Distrib 5.6.24, for Win32 (x86)
--
-- Host: localhost    Database: bil
-- ------------------------------------------------------
-- Server version	5.6.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `bil`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `bil` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `bil`;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `customerID` int(10) NOT NULL,
  `companyName` varchar(30) NOT NULL,
  `contactName` varchar(30) NOT NULL,
  `contactNumber` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `state` varchar(2) NOT NULL,
  `zipCode` int(5) NOT NULL,
  PRIMARY KEY (`customerID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (111,'Walmart','John Adams','2567026266','jadams@gmail.com','294 Copper Lane','Lychburg','TN',35630),(222,'Evans Motel','Greg Ferguson','3217941232','gferguson@live.com','4768 Highway X','Mondovi','WI',37652),(333,'Grapevine Hotel','Rose Peterson','7945218167','rosep@yahoo.com','12 Grapevine Ave.','Seattle','WA',47923),(444,'Comfort Inn','Shahee Xihang','3947564321','ShXiang@hotmail.com','4963 Highway 93','Tampa','FL',36435);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `employeeID` int(10) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `jobTitle` varchar(30) NOT NULL,
  `phoneNumber` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `state` varchar(2) NOT NULL,
  `zipCode` int(5) NOT NULL,
  PRIMARY KEY (`employeeID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (24613,'Bobby','Hill','packer','3425245343','bhill@yahoo.com','32 Hill Road','Arland','TX',23455),(25314,'Rick','Perry','maintainence','2936151763','mfrp@gmail.com','87 12th Street','Dallas','TX',23489),(31542,'Craig','Rosenvelt','clerk','2937536141','CraigRoo@bellesouth.net','1290 Ford Road','Dallas','TX',23489),(42111,'Sasha','Martinez','customer support','2936155549','Saztinez@comcast.net','87 12th Street','Dallas','TX',23489);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `orderID` int(10) NOT NULL,
  `customerID` int(10) NOT NULL,
  `productID` int(10) NOT NULL,
  `employeeID` int(10) NOT NULL,
  `shipperID` int(10) NOT NULL,
  `orderDate` varchar(20) NOT NULL,
  `arrivalDate` varchar(20) NOT NULL,
  `shipTo` varchar(30) NOT NULL,
  `shipAddress` varchar(30) NOT NULL,
  `shipCity` varchar(30) NOT NULL,
  `shipState` varchar(2) NOT NULL,
  `shipZipCode` int(5) NOT NULL,
  PRIMARY KEY (`orderID`,`customerID`,`productID`,`employeeID`,`shipperID`),
  KEY `customerID` (`customerID`),
  KEY `productID` (`productID`),
  KEY `shipperID` (`shipperID`),
  KEY `employeeID` (`employeeID`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customerID`) REFERENCES `customers` (`customerID`) ON UPDATE CASCADE,
  CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`) ON UPDATE CASCADE,
  CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`shipperID`) REFERENCES `shippers` (`shipperID`) ON UPDATE CASCADE,
  CONSTRAINT `orders_ibfk_4` FOREIGN KEY (`employeeID`) REFERENCES `employees` (`employeeID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (790,111,1128,24613,273,'7-1-15','7-12-15','Walmart','294 Copper Lane','Lychburg','TN',35630),(791,222,3425,25314,450,'7-14-15','7-4-15','Evans Motel','4768 Highway X','Mondovi','WI',37652),(792,333,7391,31542,273,'7-6-15','7-1-15','Grapevine Hotel','12 Grapevine Ave.','Seattle','WA',47923),(793,444,8592,42111,473,'6-27-15','7-2-15','Comfort Inn','4963 Highway 93','Tampa','FL',36435);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `orderID` int(10) NOT NULL,
  `paymentDate` varchar(20) NOT NULL,
  `amount` varchar(20) NOT NULL,
  `cardNumber` int(20) NOT NULL,
  PRIMARY KEY (`orderID`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`orderID`) REFERENCES `orders` (`orderID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (790,'7-20-15','$600',2147483647),(791,'7-12-15','$250',2147483647),(792,'7-6-15','$150',2147483647),(793,'7-18-15','$700',2147483647);
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `productID` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `description` varchar(30) NOT NULL,
  `manufacturedDate` varchar(20) NOT NULL,
  `arrivalDate` varchar(20) NOT NULL,
  `price` varchar(10) NOT NULL,
  PRIMARY KEY (`productID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1128,'SLF','Standard Light Fixture','6-30-15','7-4-15','$40.00'),(3425,'EE75W','Energy Efficient 75 Watt light','7-14-15','7-18-15','$1.50'),(7391,'LP','Light Panel','7-6-15','7-9-15','$70.00'),(7835,'75W','75 Watt lightbulb','7-12-15','7-16-15','$0.75'),(8592,'SL','Standard Lamp','6-20-15','6-26-15','$20.00');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shippers`
--

DROP TABLE IF EXISTS `shippers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shippers` (
  `shipperID` int(10) NOT NULL,
  `companyName` varchar(30) NOT NULL,
  `contactName` varchar(30) NOT NULL,
  `contactNumber` varchar(20) NOT NULL,
  PRIMARY KEY (`shipperID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shippers`
--

LOCK TABLES `shippers` WRITE;
/*!40000 ALTER TABLE `shippers` DISABLE KEYS */;
INSERT INTO `shippers` VALUES (273,'Umail','Sandra Bullick','7569277561'),(450,'FedEx','George Luenisky','6707831287'),(473,'InstaMail','Fredrick Pompei','8677597461');
/*!40000 ALTER TABLE `shippers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-22 19:37:53
